LM AUDIO — PROTOTIPO 0.1

QUÉ INCLUYE
- Interfaz web adaptable a iPad/iPhone.
- Controles de ganancia por canal, EQ de 3 bandas por canal y volumen master.
- Captura de audio con permiso del navegador y medidores básicos.
- Archivos PWA: manifest, service worker e iconos.

IMPORTANTE
Este paquete es una base funcional de software, NO una interfaz de audio física. Safari/iPadOS no garantiza que dos llamadas de captura sean dos entradas físicas independientes ni permite seleccionar siempre las salidas físicas por separado. El ruteo estéreo de salida utiliza la salida de audio predeterminada del sistema. El botón Monitor es una indicación de interfaz; no crea una salida física independiente.

CÓMO PROBAR EN IPAD
1. Descomprime el ZIP.
2. Sube el contenido de la carpeta lm_audio_pwa a un alojamiento estático HTTPS (por ejemplo, GitHub Pages o Netlify).
3. Abre la URL HTTPS en Safari.
4. Acepta el permiso de micrófono y pulsa “Iniciar audio”.
5. En Safari, toca Compartir > Añadir a pantalla de inicio.

No abras index.html como archivo local esperando que el micrófono o la instalación PWA funcionen: los permisos requieren un contexto seguro (HTTPS o localhost).

ARQUITECTURA PARA CRECER
- UI: HTML/CSS/JS sin dependencias externas.
- Motor actual: Web Audio API.
- Próxima etapa: prueba con interfaz USB class-compliant de 2 entradas / 2 salidas compatible con iPad y verificar exposición multicanal en Safari. Si Safari no expone todos los canales, el motor final tendrá que ser una app nativa iPadOS (Core Audio/AVAudioEngine) o una solución híbrida compatible.
- Con $500 MXN, conviene validar primero el software y compatibilidad; una interfaz USB de audio fiable de 2x2 normalmente excede ese presupuesto, por lo que no se afirma que el objetivo físico ya esté resuelto.
